package com.example.demo.pkg;

import org.springframework.stereotype.Component;

@Component
public class ABC {
}
