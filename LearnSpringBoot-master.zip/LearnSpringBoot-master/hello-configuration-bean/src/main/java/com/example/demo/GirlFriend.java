package com.example.demo;

public class GirlFriend {
    public Dress dress;

    public GirlFriend() {
    }

    public GirlFriend(Dress dress) {
        this.dress = dress;
    }

    public Dress getDress() {
        return dress;
    }

    public void setDress(Dress dress) {
        this.dress = dress;
    }
}
