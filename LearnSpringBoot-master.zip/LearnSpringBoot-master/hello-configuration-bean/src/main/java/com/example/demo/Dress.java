package com.example.demo;

public class Dress {
    public int size;

    public Dress() {
    }

    public Dress(int size) {
        this.size = size;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
