package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Dress {
    public void wear() {
        System.out.println("Đang mặc váy");
    }
}
