package com.example.demo.other_package;

import org.springframework.stereotype.Component;

@Component
public class Bikini {
    public void wear() {
        System.out.println("Đang mặc bikini");
    }
}
