package com.example.demo;

import java.util.List;

public interface DatabaseDriver {
    List<Object> getItems();
}
