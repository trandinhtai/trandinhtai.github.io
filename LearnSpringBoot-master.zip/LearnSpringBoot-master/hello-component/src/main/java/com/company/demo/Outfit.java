package com.company.demo;

public interface Outfit {
    public void wear();
}
