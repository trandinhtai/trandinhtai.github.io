package com.example.demo;

public interface Outfit {
    public void wear();
}
